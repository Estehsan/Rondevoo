# Rondevoo App

React Native App for Live Streaming 

## Tech Stack

**Client:** ReactNative Cli, Redux, React Native Paper

**Server:** Node


## Badges

Add badges from somewhere like: [shields.io](https://shields.io/)

[![MIT License](https://img.shields.io/apm/l/atomic-design-ui.svg?)](https://github.com/tterb/atomic-design-ui/blob/master/LICENSEs)
[![GPLv3 License](https://img.shields.io/badge/License-GPL%20v3-yellow.svg)](https://opensource.org/licenses/)
[![AGPL License](https://img.shields.io/badge/license-AGPL-blue.svg)](http://www.gnu.org/licenses/agpl-3.0)

  

![Simulator Screen Shot - iPhone 12 - 2021-09-05 at 14 03 54](https://user-images.githubusercontent.com/7809332/132122173-5ff2d5b9-ef70-4499-9b8e-21b6c64d7a53.png)

![Simulator Screen Shot - iPhone 12 - 2021-09-04 at 21 44 09](https://user-images.githubusercontent.com/7809332/132122215-b56c0420-cc27-4a21-9432-78e603fc6ee0.png)

