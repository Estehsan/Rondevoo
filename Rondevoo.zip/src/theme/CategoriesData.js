export default [
  {
    id: 1,
    category: 'All',
    icon: 'sports-handball',
    color: '#578ddd',
    TextColor: '#fff',
  },
  {
    id: 2,
    category: 'raw',
    icon: 'sports-volleyball',
    color: '#fff',
    TextColor: '#000',
  },
  {
    id: 3,
    category: 'raw',
    icon: 'sports-soccer',
    color: '#fff',
    TextColor: '#000',
  },
  {
    id: 4,
    category: 'raw',
    icon: 'sports-soccer',
    color: '#fff',
    TextColor: '#000',
  },
  {
    id: 5,
    category: 'asd',
    icon: 'sports-soccer',
    color: '#fff',
    TextColor: '#000',
  },
];
