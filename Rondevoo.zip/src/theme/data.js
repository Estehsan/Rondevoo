export default [
  {
    id: 'u1',
    name: 'Vadim',
    imageUri: 'https://avatars.githubusercontent.com/u/7809332?v=4',
    status: 'Hello there, how are you',
    title: 'Alpha',
  },
  {
    id: 'u2',
    name: 'Elon Musk',
    imageUri:
      'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/elon.png',
    title: 'Beta',
  },

  {
    id: 'u3',
    name: 'Jeff',
    imageUri:
      'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/jeff.jpeg',
    Title: 'Gasdas',
  },
  {
    id: 'u4',
    name: 'Zuck',
    title: 'Alpha',

    imageUri:
      'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/zuck.jpeg',
  },
  {
    id: 'u5',
    name: 'Graham',
    title: 'Alpha',

    imageUri:
      'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/graham.jpg',
  },
  {
    id: 'u6',
    name: 'Biahaze',
    title: 'Alpha',

    imageUri:
      'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/biahaze.jpg',
  },
  {
    id: 'u7',
    name: 'Sus?',
    title: 'Alpha',

    imageUri:
      'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/1.jpg',
  },
  {
    id: 'u8',
    name: 'Daniel',
    imageUri:
      'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/2.jpg',
  },
  {
    id: 'u9',
    name: 'Carlos',
    title: 'Alpha',

    imageUri:
      'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/3.jpg',
  },
  {
    id: 'u10',
    name: 'Angelina Jolie',
    title: 'Alpha',
    imageUri:
      'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/4.jpg',
  },
];
