import React from 'react';
import {StyleSheet, Text, View} from 'react-native';

const Support = () => {
  return (
    <View>
      <Text>Support</Text>
    </View>
  );
};

export default Support;

const styles = StyleSheet.create({});
