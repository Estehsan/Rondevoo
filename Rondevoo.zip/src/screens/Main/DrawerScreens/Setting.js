import React from 'react';
import {StyleSheet, Text, View} from 'react-native';

const Setting = () => {
  return (
    <View>
      <Text>Setting</Text>
    </View>
  );
};

export default Setting;

const styles = StyleSheet.create({});
